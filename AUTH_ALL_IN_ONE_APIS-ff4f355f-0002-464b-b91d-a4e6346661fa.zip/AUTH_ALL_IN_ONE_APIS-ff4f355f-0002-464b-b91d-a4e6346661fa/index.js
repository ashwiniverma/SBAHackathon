const apiService = require("apiservice");

const createErrorFormat = (errorMessage, errorCode) => {
    var jsonData = {};
    jsonData["id"] = errorCode;
    jsonData["text"] = errorMessage;
    return jsonData;
};

const createResponseFormat = (responseBody, businessErrorBody) => {
    var jsonData = {};
    if (businessErrorBody != responseBody) {
        jsonData["body"] = responseBody;
    }
    if (businessErrorBody != undefined) {
        jsonData["error"] = businessErrorBody;
    }
    return jsonData;
};


exports.handler = (event, context, callback) => {
    console.log(" Request to lambda: " + JSON.stringify(event));
    const done = (err, res) => callback(null, {
        "body" : err ? err.message : res.body,
        "statusCode" : err ? err.status : res.status,
        "headers" : {
            'Content-Type' : 'application/json',
            'Accept' : 'application/json',
            'X-Requested-With' : '*',
            'Access-Control-Allow-Origin' : '*',
            'Access-Control-Allow-Methods' : 'GET,POST,OPTIONS',
            'Access-Control-Allow-Headers' : 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,x-requested-with'
        }
    });

    if (event.path.includes("charge-customer-profile")) {
        executeChargeCustomerProfileRequest(event, done);
    } else if (event.path.includes("create-customer-profile")) {
        executeCustomerProfileRequest(event, done);
    } else if (event.path.includes("create-subscription-request")) {
        executeSubscriptionRequest(event, done);
    } else if (event.path.includes("get-transaction-list")) {
        getTransactionsList(event, done);
    }else if (event.path.includes("get-transaction-detail")) {
        getTransactionDetails(event, done);
    }else if (event.path.includes("get-merchant-details")) {
        getMerchantDetails(event, done);
    }
   
}

async function executeChargeCustomerProfileRequest(event, done) {
    await Promise.resolve(apiService.chargeCustomerProfile("","")).then(async (result) => {
        console.log(" Request to lambda: " + JSON.stringify(result));
        const response = {
            status: 200,
            body: JSON.stringify(result)
        };
        done(null, response);
    });
}

async function executeCustomerProfileRequest(event, done) {
    await Promise.resolve(apiService.customerProfileCreation("")).then(async (result) => {
        console.log(" Request to lambda: " + JSON.stringify(result));
        const response = {
            status: 200,
            body: JSON.stringify(result)
        };
        done(null, response);
    });
}


async function executeSubscriptionRequest(event, done) {
    await Promise.resolve(apiService.executeSubscriptionRequest("","")).then(async (result) => {
        console.log(" Request to lambda: " + JSON.stringify(result));
        const response = {
            status: 200,
            body: JSON.stringify(result)
        };
        done(null, response);
    });
}


async function getTransactionsList(event, done) {
    await Promise.resolve(apiService.executeTransactionsListRequest("","")).then(async (result) => {
        console.log(" Request to lambda: " + JSON.stringify(result));
        const response = {
            status: 200,
            body: JSON.stringify(result)
        };
        done(null, response);
    });
}


async function getTransactionDetails(event, done) {
    await Promise.resolve(apiService.executeTransactionDetailsRequest("","")).then(async (result) => {
        console.log(" Request to lambda: " + JSON.stringify(result));
        const response = {
            status: 200,
            body: JSON.stringify(result)
        };
        done(null, response);
    });
}

async function getMerchantDetails(event, done) {
    await Promise.resolve(apiService.executeMerchantDetailsRequest("","")).then(async (result) => {
        console.log(" Request to lambda: " + JSON.stringify(result));
        const response = {
            status: 200,
            body: JSON.stringify(result)
        };
        done(null, response);
    });
}