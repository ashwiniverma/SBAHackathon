const fetch = require("node-fetch");

const url = "https://apitest.authorize.net/xml/v1/request.api";

module.exports = {
    async chargeCustomerProfile(customerProfileId, paymentProfileId) {
        try {
            console.log("******Inside Api Call******" );
            //TODO create ramdon invoces
            const data = {"createTransactionRequest":{"merchantAuthentication":{"name":"9pWyR68w","transactionKey":"44Lk4RRf2Vvf385H"},"clientId":null,"transactionRequest":{"transactionType":"authCaptureTransaction","amount":"98.47","profile":{"customerProfileId":"1507722160","paymentProfile":{"paymentProfileId":"1507127822"}},"order":{"invoiceNumber":"INV-12645","description":"Product Description"},"lineItems":{"lineItem":[{"itemId":"1","name":"vase","description":"cannes logo","quantity":"18","unitPrice":45},{"itemId":"2","name":"vase2","description":"cannes logo2","quantity":"28","unitPrice":"25.00"}]},"shipTo":{"firstName":"China","lastName":"Bayles","company":"Thyme for Tea","address":"12 Main Street","city":"Pecan Springs","state":"TX","zip":"44628","country":"USA"}}}};
            var body = JSON.stringify(data);
            let value = {"transactionResponse":{"responseCode":"1","authCode":"XZU9J5","avsResultCode":"Y","cvvResultCode":"P","cavvResultCode":"2","transId":"40030239841","refTransID":"","transHash":"","testRequest":"0","accountNumber":"XXXX1111","accountType":"Visa","messages":[{"code":"1","description":"This transaction has been approved."}],"transHashSha2":"","profile":{"customerProfileId":"1507722160","customerPaymentProfileId":"1507127822"},"SupplementalDataQualificationIndicator":0},"messages":{"resultCode":"Ok","message":[{"code":"I00001","text":"Successful."}]}};
            return new Promise(async function (resolve, reject) {

                const response = await fetch(url, {method: 'POST',"rejectUnauthorized": false, body: body, headers: { 'Content-Type': 'application/json', 'Accept': 'application/text' }});
                console.log(" Api response from node-fetch js " + response);
                // const json = await response.json();
                // console.log(" Api response from node-fetch js "+ JSON.stringify(json));
                resolve (value);//json;
            });
        } catch (error) {
            console.error(" Error while fetching question from node-fetch js file "+ error);
        }
    },

    async customerProfileCreation(merchantId) {
        try {
            console.log("******Inside Api Call******" );

            const data = {"createCustomerProfileRequest":{"merchantAuthentication":{"name":"9pWyR68w","transactionKey":"44Lk4RRf2Vvf385H"},"profile":{"merchantCustomerId":"63486923","description":"Profile description here","email":"customer-profile-email@here.com","paymentProfiles":{"customerType":"individual","payment":{"creditCard":{"cardNumber":"4111111111111111","expirationDate":"2020-12"}}}},"validationMode":"testMode"}};
            var body = JSON.stringify(data);
            let localValue = {"customerProfileId":"1507713652","customerPaymentProfileIdList":["1507119071"],"customerShippingAddressIdList":[],"validationDirectResponseList":["1,1,1,(TESTMODE) This transaction has been approved.,000000,P,0,none,Test transaction for ValidateCustomerPaymentProfile.,1.00,CC,auth_only,63486923,,,,,,,,,,,customer-profile-email@here.com,,,,,,,,,0.00,0.00,0.00,FALSE,none,,,,,,,,,,,,,,XXXX1111,Visa,,,,,,,,,,,,,,,,,"],"messages":{"resultCode":"Ok","message":[{"code":"I00001","text":"Successful."}]}};
            return new Promise(async function (resolve, reject) {

                const response = await fetch(url, {method: 'POST',"rejectUnauthorized": false, body: body, headers: { 'Content-Type': 'application/json', 'Accept': 'application/text' }});
                console.log(" Api response from node-fetch js " + response);
                // const json = await response.json();
                // console.log(" Api response from node-fetch js "+ JSON.stringify(json));
                resolve (localValue);//json;
            });
        } catch (error) {
            console.error(" Error while fetching question from node-fetch js file "+ error);
        }
    },

    async executeSubscriptionRequest(customerProfileId, paymentProfileId) {
        try {
            console.log("******Inside Api Call******" );

            const data = {"ARBCreateSubscriptionRequest":{"merchantAuthentication":{"name":"9pWyR68w","transactionKey":"44Lk4RRf2Vvf385H"},"refId":"123456","subscription":{"name":"Sample subscription","paymentSchedule":{"interval":{"length":"1","unit":"months"},"startDate":"2020-08-30","totalOccurrences":"12","trialOccurrences":"1"},"amount":"10.29","trialAmount":"0.00","profile":{"customerProfileId":"1507722160","customerPaymentProfileId":"1507127822","customerAddressId":"1507202764"}}}};
            var body = JSON.stringify(data);
            let localValue = {"subscriptionId":"5778811","profile":{"customerProfileId":"1507722160","customerPaymentProfileId":"1507127822","customerAddressId":"1507202764"},"refId":"123456","messages":{"resultCode":"Ok","message":[{"code":"I00001","text":"Successful."}]}};
            return new Promise(async function (resolve, reject) {

                const response = await fetch(url, {method: 'POST',"rejectUnauthorized": false, body: body, headers: { 'Content-Type': 'application/json', 'Accept': 'application/text' }});
                console.log(" Api response from node-fetch js " + response);
                // const json = await response.json();
                // console.log(" Api response from node-fetch js "+ JSON.stringify(json));
                resolve (localValue);//json;
            });
        } catch (error) {
            console.error(" Error while fetching question from node-fetch js file "+ error);
        }
    },

    async executeTransactionDetailsRequest(customerProfileId, paymentProfileId) {
        try {
            console.log("******Inside Api Call******" );

            const data = {"getTransactionDetailsRequest":{"merchantAuthentication":{"name":"9pWyR68w","transactionKey":"44Lk4RRf2Vvf385H"},"transId":"40030240049"}};
            var body = JSON.stringify(data);
            let localValue = {"transaction":{"transId":"40030240049","submitTimeUTC":"2019-05-03T17:17:47.37Z","submitTimeLocal":"2019-05-03T10:17:47.37","transactionType":"authCaptureTransaction","transactionStatus":"capturedPendingSettlement","responseCode":1,"responseReasonCode":1,"responseReasonDescription":"Approval","authCode":"AH9EEX","AVSResponse":"Y","cardCodeResponse":"P","order":{"invoiceNumber":"INV-1245","description":"Product Description","discountAmount":0,"taxIsAfterDiscount":false},"authAmount":98.47,"settleAmount":98.47,"lineItems":[{"itemId":"1","name":"Pepsi","description":"cold drinks","quantity":12,"unitPrice":6,"taxable":false,"taxRate":0,"taxAmount":0,"nationalTax":0,"localTax":0,"vatRate":0,"alternateTaxRate":0,"alternateTaxAmount":0,"totalAmount":0,"discountRate":0,"discountAmount":0,"taxIncludedInTotal":false,"taxIsAfterDiscount":false},{"itemId":"2","name":"pampers","description":"20 diapers","quantity":2,"unitPrice":7.8,"taxable":false,"taxRate":0,"taxAmount":0,"nationalTax":0,"localTax":0,"vatRate":0,"alternateTaxRate":0,"alternateTaxAmount":0,"totalAmount":0,"discountRate":0,"discountAmount":0,"taxIncludedInTotal":false,"taxIsAfterDiscount":false}],"taxExempt":false,"payment":{"creditCard":{"cardNumber":"XXXX1111","expirationDate":"XXXX","cardType":"Visa"}},"customer":{"id":"6343456923","email":"customer-profile-email@here.com"},"billTo":{"phoneNumber":"000-000-0000","firstName":"John","lastName":"Doe","address":"123 Main St.","city":"Bellevue","state":"WA","zip":"98004","country":"USA"},"shipTo":{"firstName":"China","lastName":"Bayles","company":"Thyme for Tea","address":"12 Main Street","city":"Pecan Springs","state":"TX","zip":"44628","country":"USA"},"recurringBilling":false,"customerIP":"204.63.42.39","product":"Card Not Present","marketType":"eCommerce","profile":{"customerProfileId":"1507722160","customerPaymentProfileId":"1507127822"}},"messages":{"resultCode":"Ok","message":[{"code":"I00001","text":"Successful."}]}};
            return new Promise(async function (resolve, reject) {

                const response = await fetch(url, {method: 'POST',"rejectUnauthorized": false, body: body, headers: { 'Content-Type': 'application/json', 'Accept': 'application/text' }});
                console.log(" Api response from node-fetch js " + response);
                // const json = await response.json();
                // console.log(" Api response from node-fetch js "+ JSON.stringify(json));
                resolve (localValue);//json;
            });
        } catch (error) {
            console.error(" Error while fetching question from node-fetch js file "+ error);
        }
    },

    async executeTransactionsListRequest(customerProfileId, paymentProfileId) {
        try {
            console.log("******Inside Api Call******" );

            const data = {"getTransactionListForCustomerRequest":{"merchantAuthentication":{"name":"9pWyR68w","transactionKey":"44Lk4RRf2Vvf385H"},"customerProfileId":"1507722160","customerPaymentProfileId":"1507127822","sorting":{"orderBy":"submitTimeUTC","orderDescending":false},"paging":{"limit":"100","offset":"1"}}};
            var body = JSON.stringify(data);
            let localValue = {"transactions":[{"transId":"40030238965","submitTimeUTC":"2019-05-03T16:24:58.07Z","submitTimeLocal":"2019-05-03T09:24:58.07","transactionStatus":"capturedPendingSettlement","invoiceNumber":"INV-12645","firstName":"John","lastName":"Doe","accountType":"Visa","accountNumber":"XXXX1111","settleAmount":98.47,"marketType":"eCommerce","product":"Card Not Present","profile":{"customerProfileId":"1507722160","customerPaymentProfileId":"1507127822"}},{"transId":"40030240026","submitTimeUTC":"2019-05-03T17:16:49.963Z","submitTimeLocal":"2019-05-03T10:16:49.963","transactionStatus":"capturedPendingSettlement","invoiceNumber":"INV-12645","firstName":"John","lastName":"Doe","accountType":"Visa","accountNumber":"XXXX1111","settleAmount":98.47,"marketType":"eCommerce","product":"Card Not Present","profile":{"customerProfileId":"1507722160","customerPaymentProfileId":"1507127822"}},{"transId":"40030240049","submitTimeUTC":"2019-05-03T17:17:47.37Z","submitTimeLocal":"2019-05-03T10:17:47.37","transactionStatus":"capturedPendingSettlement","invoiceNumber":"INV-1245","firstName":"John","lastName":"Doe","accountType":"Visa","accountNumber":"XXXX1111","settleAmount":98.47,"marketType":"eCommerce","product":"Card Not Present","profile":{"customerProfileId":"1507722160","customerPaymentProfileId":"1507127822"}},{"transId":"40030240140","submitTimeUTC":"2019-05-03T17:26:02.39Z","submitTimeLocal":"2019-05-03T10:26:02.39","transactionStatus":"capturedPendingSettlement","invoiceNumber":"INV-12645","firstName":"John","lastName":"Doe","accountType":"Visa","accountNumber":"XXXX1111","settleAmount":98.47,"marketType":"eCommerce","product":"Card Not Present","profile":{"customerProfileId":"1507722160","customerPaymentProfileId":"1507127822"}}],"totalNumInResultSet":4,"messages":{"resultCode":"Ok","message":[{"code":"I00001","text":"Successful."}]}};
            return new Promise(async function (resolve, reject) {

                const response = await fetch(url, {method: 'POST',"rejectUnauthorized": false, body: body, headers: { 'Content-Type': 'application/json', 'Accept': 'application/text' }});
                console.log(" Api response from node-fetch js " + response);
                // const json = await response.json();
                // console.log(" Api response from node-fetch js "+ JSON.stringify(json));
                resolve (localValue);//json;
            });
        } catch (error) {
            console.error(" Error while fetching question from node-fetch js file "+ error);
        }
    },

    async executeMerchantDetailsRequest(customerProfileId, paymentProfileId) {
        try {
            console.log("******Inside Api Call******" );

            const data = {"getMerchantDetailsRequest":{"merchantAuthentication":{"name":"9pWyR68w","transactionKey":"44Lk4RRf2Vvf385H"}}};
            var body = JSON.stringify(data);
            let localValue = {"isTestMode":false,"processors":[{"name":"First Data Nashville","id":2,"cardTypes":["A","D","J","M","V"]}],"merchantName":"Ashwini Kumar","gatewayId":"706442","marketTypes":["eCommerce"],"productCodes":["CNP"],"paymentMethods":["AmericanExpress","Discover","Echeck","JCB","MasterCard","Visa"],"currencies":["USD"],"publicClientKey":"7947cX43KGGPFTy6QkKh4AwzHjV8eyJFTh8gXUr6za7U32LrxX3u9Y5pjbje48m3","businessInformation":{"phoneNumber":"425-555-1212","company":"Ashwini Kumar","address":"1 Main Street","city":"Bellevue","state":"WA","zip":"98004","country":"US"},"merchantTimeZone":"America/Los_Angeles","contactDetails":[{"email":"ashwini.mayank@gmail.com","firstName":"TestFirstName","lastName":"TestLastName"}],"messages":{"resultCode":"Ok","message":[{"code":"I00001","text":"Successful."}]}};
            return new Promise(async function (resolve, reject) {

                const response = await fetch(url, {method: 'POST',"rejectUnauthorized": false, body: body, headers: { 'Content-Type': 'application/json', 'Accept': 'application/text' }});
                console.log(" Api response from node-fetch js " + response);
                // const json = await response.json();
                // console.log(" Api response from node-fetch js "+ JSON.stringify(json));
                resolve (localValue);//json;
            });
        } catch (error) {
            console.error(" Error while fetching question from node-fetch js file "+ error);
        }
    }
};



// const getLocation = async () => {
//     try {
//         var data = {"persistentUserId" : "","merchantCleansedName" : "Verizon","recurringTransactionId" : "77d23f0bd1072f7d2a48ebf197a327de","cardReferenceId" : "oucC7LwzsQEn/Saet7d+H43siCez/i7KFuYOQqlHGDg01znMmKEwRpjQxq2b8LV4hNtURaR3fFd7NpQF7LsZqQ==","customerPreference" : "{\"updated\":\"true\"}"};
//         var body = JSON.stringify(data);
//         var url = "https://api-it.cloud.capitalone.com/private/asvcardrecurringtransactions/credit-cards/accounts/oucC7LwzsQEn%2FSaet7d%2BHzVyggTbBIz%2B1Ca%2FOgd4qkI%3D/recurring-merchants/customer-preferences";
//         const response = await fetch(url, { method: "POST","rejectUnauthorized": false, body: body, headers: {'Content-Type': 'application/json', 'Accept': 'application/json;v=1', 'Authorization': 'Bearer eyJlbmMiOiJBMTI4Q0JDLUhTMjU2IiwicGNrIjoxLCJhbGciOiJkaXIiLCJ0diI6Miwia2lkIjoicjRxIn0..12mGPjbwtv0s1O4wYOdxEQ.9UiQQYpmYkZPPsnSnMUfiTuhLPfG5ufyXNH_wVlxNeojEPtCpa8we1RzIOmTi7_w5ve-DrcHGabRv8z30LrEdP4m8T6ZV60uhDXkSW6pgpNjdRYavR3pIHuUBk-RjbssJRLyQjsHLNIKl3NkeFmmpfSbaMNKOhvy5Rizr2jwzTUoGabwhRc3Osz5OKc1ehdIR1RO0Ph5pKJJKImlKrVuxd6n8tXhzw3Z4btlBANKmLhzd-RncTyYg7OAXzWzb7saccAkcEDXwnNhEXDpK1EGfojsfnjV2I7p-PbqxAcXS94.QbaIs0_kGv66GLrjb95fqg'} });
//         // const json = await response.json();
//         console.log(response);
//         return json;
//     } catch (error) {
//         console.error(error);
//     }
// };
// getLocation(url);
