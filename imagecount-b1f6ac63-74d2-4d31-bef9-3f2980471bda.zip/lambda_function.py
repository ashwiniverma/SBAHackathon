import json

import boto3
import decimalencoder
dynamodb = boto3.resource('dynamodb')

def lambda_handler(event, context):
    table = dynamodb.Table('SBA_Objects')

    # fetch todo from the database
    result = table.get_item(
        Key={
            'objectsId': '2'
        }
    )
    
    # fetch todo from the database
    result2 = table.get_item(
        Key={
            'objectsId': '3'
        }
    )
    
    body = {
        "pampers": result['Item']['pampers'],
        "pepsi": result['Item']['pepsi'],
        "imageUrl": result['Item']['imageURL'],
        "estimate": result['Item']['totaldamage'],
        "tpampers": result2['Item']['pampers'],
        "tpepsi": result2['Item']['pepsi']
    }

    # create a response
    response = {
        "statusCode": 200,
        "body": json.dumps(body,
                           cls=decimalencoder.DecimalEncoder)
                           
    }

    return response
